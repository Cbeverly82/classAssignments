package com.cardealership.demo;

import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.logging.Logger;

@SpringBootApplication
public class CarDealership {
    private static final Logger log = LoggerFactory.getLogger(CarDealership.class);
    public static void main(String[] args) {
        SpringApplication.run(CarDealership.class, args); }

        @Bean
    public CommandLineRunner CarDealership(CarRepository repository) {
        return args -> {
            repository.save(new CarInfo("Hyundai", "Elantra"));
            repository.save(new CarInfo("Mercedes", "Benz"));
            repository.save(new CarInfo("Chevy", "Cobalt"));

            log.info("Cars found with findAll():");
            log.info("--------------------------");
            for (CarInfo carInfo : repository.findAll()) {
                log.info(carInfo.toString());
            }
            log.info("");

            repository.findById(1L)
                    .ifPresent(CarInfo ->) {
                log.info("Car found with findById(1L):");
                log.info("----------------------------");
                log.info(CarInfo.toString());
                log.info("");
            });

            log.info("----------");
            repository.findByModel("Elantra").forEach(bauer ->{
                log.info(bauer.toString());
            });
        };
    }
}
