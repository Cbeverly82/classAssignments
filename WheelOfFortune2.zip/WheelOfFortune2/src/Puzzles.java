public class Puzzles {
}
