//import java.util.ArrayList;
//import java.util.Scanner;
//
//public class Main {
//
//    public static void main(String[] args) {
//        String secretPhrase = "Houston we have a problem";
////        ArrayList<String> guesses =["a","A","b","B","c","C","d","D","e","E","f","F","g","G","h","H","i","I","j",
////                "J","k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T","u","U",
////                "v","V","w","W","x","X","y","Y","z","Z"]; //the user's guesses.
//        Scanner keyboard = new Scanner(System.in);
//        boolean notDone = true;
//        while (notDone) {
//            while (true) {
//                //print out the board
//                notDone = false;
//                for (char secretLetter : secretPhrase.toCharArray()) { //iterates over the letters
//                    if (guesses. == -1) { //not one of the guesses
//                        System.out.print('*');
//                        notDone = true;
//                    } else {
//                        System.out.print(secretLetter);
//                    }
//                }
//                if (!notDone) {
//                    break;
//                }
//                //get user's guess
//                System.out.print("\nEnter your letter:");
//                String letter = keyboard.next();
//                guesses += letter;
//            }
//            System.out.println("\nCongratulations!");
//        }
//    }
//    }
