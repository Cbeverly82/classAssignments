import java.util.ArrayList;
import java.util.Scanner;

public class WheelOfFortune2 {
    public static void main(String[] args) {
        Wheel wheel = new Wheel();
        wheel.getPuzzles("Puzzles.txt");
        wheel.setWheelConfigs("wheelConfig.txt");


        ArrayList<Player> players = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        for(int i =1; i<=3; i++) {
            System.out.println("What is the name of player " +i+"?");
            String name = scanner.next();
            Player playerName = new Player(name);
            players.add(playerName);
        }
        System.out.println("The names of your players are" + players);


        do {
            ArrayList<Character> consBank = Utils.createConsBank();
            ArrayList<Character> vowelBank = new ArrayList<>();
            vowelBank.add('A'); vowelBank.add('E'); vowelBank.add('I'); vowelBank.add('O'); vowelBank.add('U');
            wheel.getCurrentPuzzle();
            String currentAnswer = wheel.getPuzzleAnswer();
            String currentHint = wheel.getPuzzleHint();
            StringBuilder currentOutput = wheel.createOutput(currentAnswer);

            for (Player p : players) {
                p.setTempCash(0);
            }

            boolean puzzleSolved = false;

            for(Player p: players) {
                System.out.print(p.getName() + ": $" + p.getGrandCash() + "   ");
            }

            do {
                for (Player p : players) {
                    boolean playerContinue = true;
                    while (playerContinue && !puzzleSolved) {
                        System.out.println("It is " + p.getName() + "'s turn.");
                        System.out.println(p.getName() + " -GrandTotal: $" + p.getGrandCash() + "   TempCash: $" + p.getTempCash());
                        p.setTurnCash(0);

                        System.out.println(currentHint);
                        System.out.println(currentOutput);

                        int userResponse;

                        if (p.getTempCash() > 250) {
                            System.out.println("Press 3 to buy a vowel");
                        }

                        System.out.println("Press 0 to quit, 1 to spin the wheel, or 2 to solve the puzzle");
                        try {
                            userResponse = scanner.nextInt();
                        }catch(Exception e) {
                            System.out.println("Inalid Entry, you lose a turn");
                            scanner.nextLine();
                            break;
                        }

                        if(userResponse > 3) {
                            System.out.println("Invalid Entry, you lose a turn");
                            break;
                        }else if (userResponse == 0) {
                            System.exit(0);
                        } else if (userResponse == 2) {
                            scanner.nextLine();
                            System.out.println("Enter your solution: ");
                            String userSolution = scanner.nextLine().toUpperCase();

                            if (userSolution.equals(currentAnswer)) {
                                System.out.println("Correct!");
                                System.out.println(p.getName() + "solved The Puzzle!");
                                p.addSolvedCash();
                                p.addWin();
                                puzzleSolved = true;
                                break;
                            }
                        } else if (userResponse == 1) {
                            int wheelResult = wheel.spinWheel();
                            if (wheelResult == -1) {
                                System.out.println("Wheel Landed On Lose A Turn!");
                                break;
                            } else if (wheelResult == 0) {
                                System.out.println("Wheel Landed On Bankrupt!");
                                System.out.println("You're Broke!");
                                p.setBankrupt();
                                break;
                            } else {
                                p.setTurnCash(wheelResult);
                                scanner.nextLine();
                                System.out.println("Wheel Landed On $" + wheelResult);

                                boolean isConsonant = false;
                                char userCons;
                                do {
                                    System.out.println("Select A Consonant: ");
                                    userCons = scanner.nextLine().toUpperCase().charAt(0);

                                    if (!"AEIOU".contains(String.valueOf(userCons))) {
                                        isConsonant = true;
                                    }

                                    if(consBank.indexOf(userCons) == -1) {
                                        System.out.println("That letter has already been guessed");
                                        isConsonant = false;
                                    }
                                } while (!isConsonant);

                                consBank.remove(consBank.indexOf(userCons));

                                int letterCount = 0;
                                for (int i = 0; i < currentAnswer.length(); i++) {
                                    if (userCons == currentAnswer.charAt(i)) {
                                        currentOutput.setCharAt(i, userCons);
                                        letterCount++;
                                    }
                                }
                                if (letterCount == 0) {
                                    System.out.println("There aren't any " + userCons + "s in the answer");
                                    playerContinue = false;
                                    break;
                                } else {
                                    System.out.println("There are " + letterCount + " " + userCons + "s in the answer");
                                    System.out.println(currentOutput);
                                    p.addTempCash(p.getTurnCash(), letterCount);
                                    playerContinue = true;
                                }
                            }
                        } else if (userResponse == 3) {
                            if (p.getTempCash() < 250) {
                                System.out.println("You don't have enough money. Don't press 3");
                                break;
                            }
                            boolean isVowel = false;
                            char userVowel;
                            do {
                                scanner.nextLine();
                                System.out.println("Select A Vowel: ");
                                userVowel = scanner.nextLine().toUpperCase().charAt(0);

                                if ("AEIOU".contains(String.valueOf(userVowel))) {
                                    isVowel = true;
                                }
                                if(vowelBank.indexOf(userVowel) == -1) {
                                    System.out.println("That vowel has already been guessed");
                                    isVowel = false;
                                }
                            } while (!isVowel);

                            vowelBank.remove(vowelBank.indexOf(userVowel));

                            p.addTempCash(-250, 1);

                            int letterCount = 0;
                            for (int i = 0; i < currentAnswer.length(); i++) {
                                if (userVowel == currentAnswer.charAt(i)) {
                                    currentOutput.setCharAt(i, userVowel);
                                    letterCount++;
                                }
                            }
                            if (letterCount == 0) {
                                System.out.println("There aren't any " + userVowel + "s in the answer");
                                break;
                            } else {
                                System.out.println("There are " + letterCount + " " + userVowel + "s in the answer");
                                System.out.println(currentOutput);
                                playerContinue = true;
                            }

                        }
                    }
                        System.out.println("Moving To The Next Player");
                    }//end of player for-loop

                } while (!puzzleSolved) ;
                System.out.println("Moving On To The Next Puzzle");
                } while (players.get(0).getWins()<3 || players.get(1).getWins()<3 || players.get(2).getWins()<3);
        }
    }

