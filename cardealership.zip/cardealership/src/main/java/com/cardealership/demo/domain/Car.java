package com.cardealership.demo.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Car {



    public Car(String makeName, String modelName) {
        this.makeName = makeName;
        this.modelName = modelName;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String makeName;
    private String modelName;

    //uss this to create a new instance via persistance framework
    private Car() {
        //@Entity needs a Non-Argument constructor
    }

    public long getId() {
        return id;
    }

    public String getmakeName() {
        return makeName;
    }

    public String getmodelName() {
        return modelName;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setmakeName(String makeName) {
        this.makeName = makeName;
    }

    public void setmodelName(String modelName) {
        this.modelName = modelName;
    }

    @Override
    public String toString() {
        return "CarInfo{" +
                "id=" + id +
                ", makeName='" + makeName + '\'' +
                ", modelName='" + modelName + '\'' +
                '}';
    }
}
