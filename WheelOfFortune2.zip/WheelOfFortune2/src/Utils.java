import java.util.ArrayList;

public class Utils {

    public static ArrayList<Player> shiftPlayerList(ArrayList<Player> arrList) {
        Player tempPlayer = arrList.get(arrList.size() - 1);
        Player hold;
        for (int i = 0; i < arrList.size(); i++) {
            hold = arrList.get(i);
            arrList.set(i, tempPlayer);
            tempPlayer = hold;
        }
        return arrList;
    }

    public static ArrayList<Character> createConsBank() {
        ArrayList<Character> consBank = new ArrayList<>();
        for (int i = 65; i < 91; i++) {
            char newChar = (char) i;
            if (!"AEIOU".contains(String.valueOf(newChar))) {
                consBank.add(newChar);
            }
        }
        return consBank;
    }
}
