package com.cardealership.demo.domain;

public interface CarRepository {
}
